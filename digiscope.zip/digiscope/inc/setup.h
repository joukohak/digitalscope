
void GPIO_setup(void);
void UART1_Config(void);
void clock_setup(void);
void ADC1_setup(void);
