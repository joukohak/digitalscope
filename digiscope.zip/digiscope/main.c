#include "STM8S.h"
#include "setup.h"
#include "timer1.h"

// ASCII values for the commands

#define		STREAM			0x33
#define		STOP			0x34
#define	  SINE			0x31
#define	  ACDCIN			0x32

#define   ACINPUT	GPIO_WriteLow(GPIOA,GPIO_PIN_3)
#define   DCINPUT	GPIO_WriteHigh(GPIOA,GPIO_PIN_3)


#define BLE_WAKEUP	GPIO_WriteLow(GPIOB,GPIO_PIN_5)    // Wakeup BLE
#define PWRC_OFF	GPIO_WriteHigh(GPIOB,GPIO_PIN_5)    // PWRC=1
#define POWER_ON	GPIO_WriteHigh(GPIOA,GPIO_PIN_1)	//Power switch on
#define POWER_OFF	GPIO_WriteLow(GPIOA,GPIO_PIN_1)	  //Power switch off

#define		BUFFERSIZE		600    // 300 samples

unsigned char TXByte;		// Value sent over UART when Transmit() is called
unsigned char RXByte;// Value recieved once hasRecieved is set
unsigned char RXbuf[10], bufindex=0, readindex=0 ;  //uart rxbuffer 4 bytes
unsigned short int STime=20;
const unsigned short int SampleRate[8] = {20,40,200,400,800,2000,4000,20000};  // half timer period count-1 20= 5us
unsigned char i;				// for loop variable
unsigned char isTriggered=0, sineon=0;			// trigger detected, sinewave output
unsigned char hasReceived=0;			// Lets the program know when a byte is received
unsigned char ADCDone=0,isRisingEdge=1;				// ADC Done flag, rising edge trigger


unsigned short int ADCValue;		   // Measured ADC Value
unsigned int TxValue;		   // Tx ADC Value
unsigned int count=0,triggercount=0,power_off_delay=0;
@near unsigned char readADC[600];
// Function Definitions
void Transmit(void);
void Receive(void);

void Single_Measure(unsigned int);
void Single_Measure_REF(unsigned int, unsigned int);
void Start_Stream(void);
void Stop_Stream(void);
void SendData(void);
void SendBuffer(void);
void triggerADC(void);
void Ble_Wakeup_Pulse(void);
void UART_print(char *string);
uint16_t ADCchannel(uint8_t channel);




void main()
{
		
	clock_setup();
	GPIO_setup();
	ADC1_setup();
	TIM1_Config();
	UART1_Config();
	delay_ms(1000);
	
//	Ble_Wakeup_Pulse();
//	delay_ms(1000);
//	UART_print("AT+NEIN0");  // 100ms connection interval
//	delay_ms(500);
//	UART_print("AT+ADVIN4");  // 500ms broadcast interval
//	delay_ms(500);
	
	hasReceived = 0;
	ADCDone = 0;
	
	
	if (ADCchannel(3) < 650 ){ 
		POWER_ON;
	}
	
	ADC1_setup();
	TIM1_Config();

    

	while(1)
	{
		if ((hasReceived==1)||(bufindex !=0))			// If the device has received a value
		{
			Receive();
			power_off_delay =0;
			
		}
		
		if(ADCDone==1)					// If the ADC is done with a measurement
		{
			
  // 			Stop_Stream();
				SendBuffer();


			ADCDone = 0;				    // Clear flag
		}
		delay_ms(100);
		if (++power_off_delay > 6000) POWER_OFF;  
		
	}

    
  //  return (0);
	
	
}
// Send  ADC values buffer

void SendBuffer(void)
{
	unsigned int index;
	TXByte = 0x2B;
	SendData();

		
	for(index=0; index < BUFFERSIZE/2; index++)
		     {
			      TXByte = readADC[2*index];
			      SendData();
						TXByte = readADC[(2*index)+1];
			      SendData();
				
		     }

	TXByte = 0xFF;
	SendData();

}

void SendData(void){
	Transmit();
}

/**
 * Handles the received byte and calls the needed functions.\
 **/
void Receive()
{
	hasReceived = 0;	// Clear the flag
	while (bufindex > 0) {
		RXByte = RXbuf[readindex++];
		switch(RXByte)			// Switch depending on command value received
		{
		
			case STREAM:
				Start_Stream();			// Starts continuously reading A4
			break;

			case STOP:
				Stop_Stream();					// Stops the ADC
			break;
		
			case SINE:
				sineon = TIM2->IER ^ 0x01;			
				TIM2->IER  = sineon;					// Sinewave out on/off
			// capture compare to output pin enabled/disabled
				TIM2->CCER1 = sineon;
			break;
			
			case ACDCIN:
				GPIOA->ODR  = GPIOA->ODR ^ 0x08;					// AC/DC IN toggle
			break;	

		
			default:;
    }
		if (RXByte >= 0xe0){
			STime = SampleRate[(RXByte - 0xe0)]-1;
				// Timer 1  trigger period
			TIM1->ARRH  = (STime >> 8)& 0xFF ;			 // sample period
			TIM1->ARRL  = (STime & 0xFF); 
		}else if (RXByte >= 0xC0){							// Trigger voltage set
			isRisingEdge = RXByte & 0x01;
			triggerADC();
		}
		if (readindex > bufindex){
			bufindex = 0;
			readindex = 0;
		}
	}
}
/**
 * Starts to continuously read the 'chan'. The reference used is AVCC and not
 * 	an internal reference.
 **/



/**
 * Stops the ADC.
 **/
void Stop_Stream()
{

}
// 0.5 VCC Trigger ADC

void triggerADC(void)
{
	isTriggered = 0;
	
	Start_Stream();
	
	SendBuffer();
	
}

void Transmit(void)
{
		     /* Write one byte to the transmit data register */
			UART1->DR = TXByte;
					 /* Wait until end of transmit */
			while ((UART1->SR & 0x80)== RESET);
}

void ADC_start(void)
{
	count=0;
	ADCDone=0;
		// EOC clear ,Bit 5 EOCIE=0: Interrupt enable for EOC, CH 4 select
	ADC1->CSR  = 0x04; 
	delay_ms(1);

	// ADC trigger timer1 channel1
	ADC1->CR2 = 0x48;
		// Timer 1  trigger period
	TIM1->ARRH  = (uint8_t) (STime >> 8)& 0xFF ;			 // sample period
  TIM1->ARRL  = (uint8_t)(STime & 0x00FF); 
  
  // Auto preload, upcounter ,no one pulse mode,counter enable 
	TIM1->CR1  = 0x81;
	//	ADC1 ON , Single conversion mode
	ADC1->CR1 = 0x01;
}	



void Start_Stream(void)
{
	ADC_start();
		
	while (count < 600)
	{
		// wait for EOC to set
		while((ADC1->CSR & 0x80) == FALSE);
		readADC[count+1] = ADC1->DRL;
    // Then read MSB
		readADC[count] = ADC1->DRH;
			
		// EOC bit7 clear, bit5 EOCIE off , bit3-0 CH 4
		ADC1->CSR  = 0x04;

		count = count + 2;
		if (count >= 600 ){
			  
			  // counter DISABLE 
			TIM1->CR1  = 0x80;

		}
	}
	ADCDone=1;
	count=0;

	
}

void Ble_Wakeup_Pulse(void)
{
	BLE_WAKEUP;    // wake ble from sleep
	delay_ms(500);
	PWRC_OFF;			// set PWRC / Button input to high
}

void UART_print(char *string)
{
    while (*string) {
			UART1->DR = *string++ ;
					 /* Wait until end of transmit */
			while ((UART1->SR & 0x80)== RESET);
    }
}



//  AD Conversion selected  channel  input  

uint16_t ADCchannel(uint8_t channel)
{
	uint16_t	readAD;
  uint8_t templ = 0;

  ADC1->CSR  = channel; 	//ad channel select
	delay_ms(20);
//	ADC1_StartConversion();
	ADC1->CR1 |= ADC1_CR1_ADON;
	while((ADC1->CSR & 0x80) == FALSE);
		templ = ADC1->DRL;
    /* Then read MSB */
    readAD = ADC1->DRH;
    readAD = (uint16_t)(templ | (uint16_t)(readAD << 8));	

		ADC1->CSR  = 0x04;								
	return readAD;
}
