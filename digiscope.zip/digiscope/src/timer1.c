/**
  * @brief  Configure TIM1 to allow 1 sec rtc
  * @param  None
  * @retval None
  */
#include "stm8s.h"	
	
void TIM1_Config(void)
{
  //TIM1_DeInit();
	
	
  /* Time base configuration */

	
  
	TIM1->PSCRH = 0x00;      // prescaler 1+1 = 4 MHz
  TIM1->PSCRL = 0x01;
	TIM1->ARRH  = 0x00;			 // div 20 =5us
  TIM1->ARRL  = 0x13;
 
  
  // Auto preload, upcounter ,no one pulse mode,counter disable 
	TIM1->CR1  = 0x80;
	//  Update as TRGO trigger to ADC
	TIM1->CR2  = 0x20;
	
// Timer 2 init 	
	TIM2->PSCR = 0x00;   // Prescaler 8MHz clk
	TIM2->ARRH  = 0x01;			 // period 31us
  TIM2->ARRL  = 0x3F;
	// TIM2 CCR1 PWM OUTPUT
	TIM2->CCMR1 = 0x68;
	// TIM2 CCR3 PWM OUTPUT
	//TIM2->CCMR3 = 0x68;
	
	// Timer2 CCR1 PWM period
	TIM2->CCR1H = 0x00;
  TIM2->CCR1L = 0x70;
	
// capture compare to output pin disabled
	TIM2->CCER1 = 0x00;

	// timer2 auto preload
	TIM2->CR1  = 0x81;
  
}

